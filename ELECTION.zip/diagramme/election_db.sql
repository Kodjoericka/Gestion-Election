/*==============================================================*/
/* Nom de SGBD :  PostgreSQL 8                                  */
/* Date de cr�ation :  04/05/2024 19:00:19                      */
/*==============================================================*/


drop table Candidat;

drop table Delegue;

drop table Etudiant;

drop table Vote;

/*==============================================================*/
/* Table : Candidat                                             */
/*==============================================================*/
create table Candidat (
   matriculeEt          INT4                 not null,
   matriculeCandidat    INT4                 not null,
   nomCandidat          VARCHAR(254)         null,
   prenomCandidat       VARCHAR(254)         null,
   niveau               INT4                 null,
   filiere              VARCHAR(254)         null,
   numeroCandidat       INT4                 null,
   constraint PK_CANDIDAT primary key (matriculeEt, matriculeCandidat),
   constraint AK_IDENTIFIANT_2_CANDIDAT unique (matriculeCandidat)
);

/*==============================================================*/
/* Table : Delegue                                              */
/*==============================================================*/
create table Delegue (
   matriculeDel         INT4                 not null,
   numeroCandidat       INT4                 not null,
   nomDel               VARCHAR(254)         null,
   prenomDel            VARCHAR(254)         null,
   niveau               INT4                 null,
   filiere              VARCHAR(254)         null,
   constraint PK_DELEGUE primary key (matriculeDel)
);

/*==============================================================*/
/* Table : Etudiant                                             */
/*==============================================================*/
create table Etudiant (
   matriculeEt          INT4                 not null,
   matriculeDel         INT4                 null,
   numeroCandidat       INT4                 null,
   nomEt                VARCHAR(254)         null,
   prenomEt             VARCHAR(254)         null,
   niveau               INT4                 null,
   filiere              VARCHAR(254)         null,
   constraint PK_ETUDIANT primary key (matriculeEt)
);

/*==============================================================*/
/* Table : Vote                                                 */
/*==============================================================*/
create table Vote (
   numeroCandidat       INT4                 not null,
   nombreVoix           INT4                 null,
   constraint PK_VOTE primary key (numeroCandidat)
);

alter table Candidat
   add constraint FK_CANDIDAT_GENERALIS_ETUDIANT foreign key (matriculeEt)
      references Etudiant (matriculeEt)
      on delete restrict on update restrict;

alter table Delegue
   add constraint FK_DELEGUE_CONSULTE_VOTE foreign key (numeroCandidat)
      references Vote (numeroCandidat)
      on delete restrict on update restrict;

alter table Etudiant
   add constraint FK_ETUDIANT_ASSOCIATI_DELEGUE foreign key (matriculeDel)
      references Delegue (matriculeDel)
      on delete restrict on update restrict;

alter table Etudiant
   add constraint FK_ETUDIANT_VOTE_VOTE foreign key (numeroCandidat)
      references Vote (numeroCandidat)
      on delete restrict on update restrict;

