import java.util.*;
public class Affichernombre{
            public static void main (string[]args);
            {
                 int a;
                 Scanner val = new Scanner (system.in);
                 //int resultat= multiplication *i;
                for ( i=0;i<=12; i++){
                   resultat= a*i;
                  System.out.println(i+"*" + a + "="+resultat);
            }
}
}