import java.util.*;
public class Temperature
{
    public static void main(String[] args){
      int t;
        Scanner tem=new Scanner(System.in);
        System.out.println("Entrez la temperature de l'eau :");
         t = tem.nextInt();
         if ( t<=0){
            System.out.println("A cette temperature votre eau est glacee.");
         }
         else if(t> 0 && t< 100) {
            System.out.println("A cette temperature votre eau est liquide.");
         }
         else{
            System.out.println("A cette temperature votre eau est gazeuse.");
         }
    }
}