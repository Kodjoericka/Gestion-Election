import java.util.*;
public class Nombre{
    public static void main(String[] args)
    {
        int a;
        Scanner val=new Scanner(System.in);
        System.out.println("Entrez un nombre !");
        a= val.nextInt();
        while(a<=0 || a>0){
            System.out.println("le nombre est incorrect. veuillez entrez un nombre positif s'il vous plait ");
         // a= val.nextInt();
        }
    }
}