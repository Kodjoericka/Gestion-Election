import java.util.*;
public class SommeNombre
{
public static void main(string[]args)
{
    int a,b,s;
    scanner val= new scanner(system.in);
    system.out.println( x: "entre deux nombre");
    a = val.nextInt();
    b =val.nextInt();
    if (a>0 && b>0){
        s = a+b;
        system.out.println(a+"+"+b+"="+s);
           }
    else {
        system.out.println( erreur);
    }
}
}
