import java.util.*;
public class While{
    public static void main(String[] args)
    {
        int a;
        Scanner val=new Scanner(System.in);
        System.out.println("Entrez un nombre !");
        a= val.nextInt();

    }
}